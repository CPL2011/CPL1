package examples;

public class RunAllExamples
	{
	public static void main(String[] args) {
	examples.socialnetwork.SocialNetwork.main(args);
	examples.fluspreading.FluSpreading.main(args);
	}
}